Zikao TV self-hosted video files go in this folder.
Use MP4 (H.264 video + AAC audio) for best browser compatibility.
After adding a file, register it in the VIDEOS array in ../index.html, e.g.
{id:"sample-report",title:"Sample report",description:"Description",date:"2026-10-20",src:"videos/sample-report.mp4"}
To attach a video to a news story, add video:"videos/sample-report.mp4" to that story object in STORIES.
Do not upload README.txt as a video; replace the example path with your actual filename.
